= Measuring Performance of Behavior =

- RES & SPY: Should you select yourself or not?
- RES & SPY: Should you vote up your own missions?

- SPY: Should you select spies or not?
- SPY: Should you vote for spies or not?

! Measure correlation between winning and these behaviors.


= Measuring Properties of the Game =

- RES & SPY: How does increasing selection rate change performance?
- RES & SPY: How does increasing voting rate change performance?
- RES & SPY: Show impact of false-negatives vs. false- positives.

- RES & SPY: Correlation between being voted up and winning.
- RES & SPY: Correlation between being selected and winning.

