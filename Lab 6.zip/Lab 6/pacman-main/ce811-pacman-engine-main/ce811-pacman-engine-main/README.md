# ce811-pacman-engine

This engine was originally created at UC Berkeley, primarily by John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu), and is re-used in CE811 with permission.

To use the engine as a keyboard controlled game use "python3 pacman.py"

See CE811 moodle for more information.

M. Fairbank, July 2021

