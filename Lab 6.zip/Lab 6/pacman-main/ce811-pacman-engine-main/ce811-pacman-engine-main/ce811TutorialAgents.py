# ce811TutorialAgents.py
# --------------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html
#
# Adapted for CE811 by M. Fairbank
# Put your agents for the CE811 pacman tutorial in here.

from util import manhattanDistance
from game import Directions, Actions
import random, util

from game import Agent


class ce811GoWestAgent(Agent):

  def getAction(self, gameState):
    legalMoves = gameState.getLegalActions()
    return Directions.WEST
    #return random.choice(legalMoves) 

class ce811GoSouthWestAgent(Agent):
  def getAction(self, gameState):
    legalMoves = gameState.getLegalActions()
    if 'South' in legalMoves:
      return 'South'
    elif 'West' in legalMoves:
      return 'West'
    else:
      return random.choice(legalMoves)
# TODO improve this logic to head SOUTH (first priority) then WEST (second priority)

class ce811ManhattanFoodSeekerAgent(Agent):

  def getAction(self, gameState):
    legal_moves = gameState.getLegalActions()
    pacman_pos = gameState.getPacmanPosition()
    #print("pacman_pos",pacman_pos) # useful for debugging
    food_locations=gameState.getFood().asList()
    assert len(food_locations)==1,"For this exercise, we should always run this crossMaze with the commnadline option: -d 1"
    food_location=food_locations[0] #gets the first value of the list (there's only one food item in this board!)
    #print("food_location",food_location) # useful for debugging
    # Note that pacman_pos and food_location are both tuples of the form (x,y).
    # The origin is such that (0,0) is the top-left of the game board
    # Hence if the food's y coordinate is higher than pacman's y coordiante then we know the food is below us.
    # Similarly, if the food's x coordinate is higher than pacman's x coordiante then we know the food is to the east of us.
    food_x,food_y=food_location # unpack the tuple (x,y) into some more conventient variable names
    pacman_x,pacman_y=pacman_pos # unpack the tuple (x,y) into some more conventient variable names
    if food_y>pacman_y:
        return Directions.SOUTH # TODO fix this
    elif food_y<pacman_y:
        return Directions.NORTH # TODO fix this
    elif food_x>pacman_x:
        return Directions.EAST # TODO fix this
    elif food_x<pacman_x:
        return Directions.WEST # TODO fix this
    # Should never get here!
    raise Exception("Should never get here")
  

class ce811ManhattanGhostDodgerAgent(Agent):
    def getAction(self, gameState):
        legal_moves = [a for a in gameState.getLegalActions() if a != Directions.STOP]
        pacman_x,pacman_y = gameState.getPacmanPosition() # unpack the tuple (x,y) into some more conventient variable names
        food_locations = gameState.getFood().asList()
        (ghost_x,ghost_y) = gameState.getGhostPositions()[0]
        ghost_movement_directions = gameState.getGhostStates()[0].getDirection()
        # Tip, try removing any directions that would lead you directly towards the ghost...
        def go_vert(prefer_up=True):
            if prefer_up and Directions.NORTH in legal_moves:
               return Directions.NORTH
            if not prefer_up and Directions.SOUTH in legal_moves:
               return Directions.SOUTH
            if Directions.NORTH in legal_moves:
               return Directions.NORTH
            if Directions.SOUTH in legal_moves:
               return Directions.SOUTH
            return None
    # Repeat the above logic for each direction.
    # Now add some logic to make pacman head towards the food, only choosing moves from "good_moves"
    # TODO..
    # End of function, return a good move, if not exited already...
        def go_to_nearest_on_row(y):
            row_food=[f for f in food_locations if f[1]==y]
            if not row_food:
               return None
            tx,_=min(row_food,key=lambda t: abs(t[0]-pacman_x))
            if tx>pacman_x and Directions.EAST in legal_moves:
               return Directions.EAST
            if tx<pacman_x and Directions.WEST in legal_moves:
               return Directions.WEST
            return None

        same_row=(pacman_y==ghost_y)
        approaching=(ghost_movement_directions==Directions.EAST and ghost_x<pacman_x) or \
                      (ghost_movement_directions==Directions.WEST and ghost_x>pacman_x)
        too_close=abs(ghost_x-pacman_x)<=3

        if same_row and (approaching or too_close):
            return go_vert(prefer_up=(pacman_y<ghost_y)) or legal_moves[0]
        if same_row:
            return go_vert(prefer_up=(ghost_y>pacman_y)) or legal_moves[0]

        move=go_to_nearest_on_row(pacman_y)
        if move: return move

        move=go_vert(prefer_up=(ghost_y>pacman_y))
        if move: return move

        if food_locations:
            tx,ty=min(food_locations,key=lambda t: abs(t[0]-pacman_x)+abs(t[1]-pacman_y))
            if tx>pacman_x and Directions.EAST in legal_moves:
               return Directions.EAST
            if tx<pacman_x and Directions.WEST in legal_moves:
               return Directions.WEST
            if ty>pacman_y and Directions.NORTH in legal_moves:
               return Directions.NORTH
            if ty<pacman_y and Directions.SOUTH in legal_moves:
               return Directions.SOUTH
        return legal_moves[0] if legal_moves else Directions.STOP



class ce811ManhattanGhostDodgerHunterAgent(Agent):
  def getAction(self, gameState):
    legal_moves = gameState.getLegalActions()
    # Collect legal moves and successor states
    legal_moves = [m for m in legal_moves if m != Directions.STOP] or [Directions.STOP]
    #locate pacman
    pacman_pos = gameState.getPacmanPosition()
    #locate ghosts
    ghost_states = gameState.getGhostStates()
    ghost_scared_times = [ghostState.scaredTimer for ghostState in ghost_states]
    ghost_positions = gameState.getGhostPositions()
    #locate closest food dot:
    food_locations=gameState.getFood().asList()
    any_scared=any(time > 1 for time in ghost_scared_times)
    # TODO add your code logic here...
    best_score = float('-inf')
    best_moves = []
    for action in legal_moves:
        dx,dy=Actions.directionToVector(action)
        new_pos=(int(pacman_pos[0]+dx),int(pacman_pos[1]+dy))
        score=0
        ghost_distances=[manhattanDistance(new_pos, ghost_pos) for ghost_pos in ghost_positions]
        ghost_distances_scared = [ghost_dist for ghost_dist, time in zip(ghost_distances, ghost_scared_times) if time>1]
        ghost_distances_dangerous = [ghost_dist for ghost_dist, time in zip(ghost_distances, ghost_scared_times) if time<=1]

        if any_scared:
            if ghost_distances_scared:
                score=score-min(ghost_distances_scared)
            if ghost_distances_dangerous:
                dmin=min(ghost_distances_dangerous)
                if dmin==0:
                    score=score-1000
                else:
                    score=score+dmin*2
        else:
            if new_pos in food_locations:
                score=score+10
            if food_locations:
                food_distances=[manhattanDistance(new_pos,food_pos) for food_pos in food_locations]
                score=score-min(food_distances)*0.5
            if ghost_distances_dangerous:
                dmin = min(ghost_distances_dangerous)
                if dmin==0:
                    score=score-1000
                else:
                    score=score+dmin*2
        if score>best_score:
            best_score=score
            best_moves=[action]
        elif score==best_score:
            best_moves.append(action)
    return random.choice(best_moves)
